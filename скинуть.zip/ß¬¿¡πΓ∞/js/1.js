
const firstNum = prompt('What is Bitcoin price today','');
const secondNum = prompt('How much $ do you have?','');
///alert(+firstNum * + secondNum);
document.write('You can buy '+firstNum * + secondNum + 'BTC' )